import 'package:flutter/material.dart';
class profileUpdateScreen extends StatefulWidget {
  const profileUpdateScreen({Key? key}) : super(key: key);

  @override
  State<profileUpdateScreen> createState() => _profileUpdateScreenState();
}

class _profileUpdateScreenState extends State<profileUpdateScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
